@extends('layouts.app')

@section('content')
<div class="vote-hero">
    <div>
        <span class="eyebrow">Ruang pengelola</span>
        <h1 class="display-title">Bangun daftar<br><em>calon terbaik.</em></h1>
        <p class="lead">Tambahkan pasangan calon, lengkapi gagasan mereka, dan siapkan bilik suara untuk seluruh siswa.</p>
    </div>
    <aside class="hero-note"><span>03</span><p>Lengkapi data pasangan, lalu cek hasilnya di halaman publik.</p></aside>
</div>

<div class="section-heading">
    <div><span class="eyebrow">Data pemilihan</span><h2>Tambah pasangan calon</h2></div>
    <p>Semua kolom bertanda wajib diisi.</p>
</div>

<section class="form-panel">
    <form action="/admin/tambah-paslon" method="POST">
        @csrf
        <div class="form-grid">
            <div class="field"><label for="nomor_urut">Nomor urut</label><input id="nomor_urut" type="number" name="nomor_urut" min="1" required placeholder="01"></div>
            <div class="field"><label for="foto">URL foto pasangan <span>(opsional)</span></label><input id="foto" type="url" name="foto" placeholder="https://...jpg"></div>
            <div class="field"><label for="ketua">Nama ketua</label><input id="ketua" type="text" name="ketua" required placeholder="Nama lengkap ketua"></div>
            <div class="field"><label for="wakil">Nama wakil</label><input id="wakil" type="text" name="wakil" required placeholder="Nama lengkap wakil"></div>
            <div class="field field-wide"><label for="visi">Visi</label><textarea id="visi" name="visi" required placeholder="Tuliskan visi pasangan calon..."></textarea></div>
            <div class="field field-wide"><label for="misi">Misi</label><textarea id="misi" name="misi" required placeholder="Tuliskan misi utama pasangan calon..."></textarea></div>
        </div>
        <div class="form-actions"><button type="submit" class="btn-primary">Simpan pasangan calon</button></div>
    </form>
</section>
@endsection

@extends('layouts.app')

@section('content')
<section class="vote-hero" style="min-height: 56vh; align-items: center;">
    <div>
        <span class="eyebrow">Pemilihan Ketua OSIS · 2026</span>
        <h1 class="display-title">Waktunya<br><em>suaramu didengar.</em></h1>
        <p class="lead">Selamat datang di ruang pemilihan digital sekolah. Kenali pasangan calon, pahami gagasan mereka, dan ambil bagian dalam perubahan.</p>
        <div style="display:flex; gap:12px; margin-top:28px;">
            <a class="btn-primary" href="/login-test">Masuk ke bilik suara</a>
            <a class="btn-primary" href="/hasil" style="background:var(--navy);">Lihat hasil live</a>
        </div>
    </div>
    <aside class="hero-note">
        <span>01</span>
        <p>Setiap suara adalah kesempatan untuk memilih arah sekolah yang lebih baik.</p>
    </aside>
</section>

<section class="section-heading" style="margin-top: 24px;">
    <div>
        <span class="eyebrow">Cara ikut serta</span>
        <h2>Suara yang berarti dimulai dari langkah kecil.</h2>
    </div>
    <p>Ringkas, transparan, dan mudah diikuti.</p>
</section>

<div class="candidate-grid">
    <article class="candidate-card" style="padding: 28px;">
        <span class="candidate-label">01 · Kenali</span>
        <h3 class="candidate-name">Baca gagasan mereka</h3>
        <p class="vision">Pelajari visi dan misi setiap pasangan calon sebelum menentukan pilihan.</p>
    </article>
    <article class="candidate-card" style="padding: 28px;">
        <span class="candidate-label">02 · Pilih</span>
        <h3 class="candidate-name">Gunakan hak suaramu</h3>
        <p class="vision">Masuk ke bilik suara dan pilih pasangan calon yang paling mewakili harapanmu.</p>
    </article>
    <article class="candidate-card" style="padding: 28px;">
        <span class="candidate-label">03 · Pantau</span>
        <h3 class="candidate-name">Ikuti hasilnya</h3>
        <p class="vision">Lihat perolehan suara sementara melalui halaman hasil live pemilihan.</p>
    </article>
</div>
@endsection

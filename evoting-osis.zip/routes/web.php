<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\VoteController;
use App\Models\User;

Route::get('/', function () {
    return view('welcome');
});

// Rute sementara untuk simulasi Login Siswa (karena kita belum buat halaman login)
Route::get('/login-test', function () {
    $user = User::firstOrCreate(
        ['email' => 'siswa1@sekolah.com'],
        ['name' => 'Budi Siswa', 'password' => bcrypt('rahasia')]
    );
    auth()->login($user);
    return redirect('/vote');
});

// Rute untuk halaman E-Voting
Route::get('/vote', [VoteController::class, 'index']);
Route::post('/vote', [VoteController::class, 'store']);
// Rute untuk Halaman Panel Admin
Route::get('/admin', [VoteController::class, 'admin']);
Route::post('/admin/tambah-paslon', [VoteController::class, 'storeCandidate']);
// Rute untuk Halaman Hasil Live
Route::get('/hasil', [VoteController::class, 'hasil']);
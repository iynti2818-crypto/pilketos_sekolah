<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e($title ?? 'Suara Kita'); ?> | Pemilihan Ketua OSIS</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="app-shell">
    <div class="ambient ambient-one"></div>
    <div class="ambient ambient-two"></div>

    <header class="site-header">
        <a href="/vote" class="brand" aria-label="Suara Kita - Bilik Suara">
            <span class="brand-mark">SK</span>
            <span>
                <strong>SUARA KITA</strong>
                <small>Pemilihan Ketua OSIS</small>
            </span>
        </a>
        <nav class="main-nav" aria-label="Navigasi utama">
            <a href="/vote" class="<?php echo e(request()->is('vote') ? 'active' : ''); ?>"><span class="nav-icon">01</span>Bilik suara</a>
            <a href="/hasil" class="<?php echo e(request()->is('hasil') ? 'active' : ''); ?>"><span class="nav-icon">02</span>Hasil live</a>
            <a href="/admin" class="<?php echo e(request()->is('admin') ? 'active' : ''); ?>"><span class="nav-icon">03</span>Panel admin</a>
        </nav>
    </header>

    <main class="page-wrap">
        <?php if(session('success')): ?>
            <div class="flash flash-success" role="status"><span class="flash-dot"></span><?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="flash flash-error" role="alert"><span class="flash-dot"></span><?php echo e(session('error')); ?></div>
        <?php endif; ?>
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <footer class="site-footer">
        <span>OSIS 2026</span>
        <span>Suaramu menentukan arah sekolah.</span>
    </footer>
</body>
</html>
<?php /**PATH C:\Users\USER\evoting-osis\resources\views/layouts/app.blade.php ENDPATH**/ ?>
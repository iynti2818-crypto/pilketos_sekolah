

<?php $__env->startSection('content'); ?>
<div class="vote-hero">
    <div>
        <span class="eyebrow">Bilik suara digital · 2026</span>
        <h1 class="display-title">Satu pilihan.<br><em>Satu arah baru.</em></h1>
        <p class="lead">Kenali gagasan setiap pasangan calon, lalu gunakan hak pilihmu untuk menentukan cerita OSIS tahun ini.</p>
    </div>
    <aside class="hero-note">
        <span><?php echo e($candidates->count()); ?></span>
        <p>pasangan calon siap mendengar dan mewakili suara siswa.</p>
    </aside>
</div>

<div class="section-heading">
    <div>
        <span class="eyebrow">Pilihanmu dimulai di sini</span>
        <h2>Pasangan calon</h2>
    </div>
    <p>Geser lebih dekat, baca visi mereka.</p>
</div>

<div class="candidate-grid">
    <?php $__empty_1 = true; $__currentLoopData = $candidates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <article class="candidate-card">
            <div class="candidate-top">
                <div class="candidate-number"><?php echo e(str_pad($c->nomor_urut, 2, '0', STR_PAD_LEFT)); ?></div>
                <?php if($c->foto): ?>
                    <img class="candidate-photo" src="<?php echo e($c->foto); ?>" alt="Foto <?php echo e($c->nama_ketua); ?> dan <?php echo e($c->nama_wakil); ?>">
                <?php else: ?>
                    <div class="candidate-initials" aria-hidden="true"><?php echo e(strtoupper(substr($c->nama_ketua, 0, 1))); ?></div>
                <?php endif; ?>
            </div>
            <div class="candidate-copy">
                <span class="candidate-label">Pasangan calon <?php echo e($c->nomor_urut); ?></span>
                <h3 class="candidate-name"><?php echo e($c->nama_ketua); ?> <span>bersama</span> <?php echo e($c->nama_wakil); ?></h3>
                <p class="vision"><?php echo e($c->visi_misi); ?></p>
            </div>
            <div class="candidate-footer">
                <small>Pilih dengan sadar. Suaramu bersifat rahasia.</small>
                <form action="/vote" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="candidate_id" value="<?php echo e($c->id); ?>">
                    <button type="submit" class="btn-primary" <?php echo e(auth()->user()->has_voted ? 'disabled' : ''); ?>>
                        <?php echo e(auth()->user()->has_voted ? 'Sudah memilih' : 'Pilih paslon'); ?>

                    </button>
                </form>
            </div>
        </article>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="empty-state">Belum ada pasangan calon yang ditambahkan.</div>
    <?php endif; ?>
</div>

<?php if(auth()->user()->has_voted): ?>
    <div class="status-banner"><strong>Pilihanmu sudah tercatat.</strong> Terima kasih sudah ikut menentukan masa depan OSIS.</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\evoting-osis\resources\views/vote/index.blade.php ENDPATH**/ ?>
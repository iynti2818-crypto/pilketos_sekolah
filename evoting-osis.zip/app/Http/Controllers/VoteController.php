<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Candidate;
use App\Models\Vote;
use Illuminate\Support\Facades\Auth;

class VoteController extends Controller
{
    // Fungsi untuk menampilkan halaman daftar kandidat
    public function index()
    {
        $candidates = Candidate::all();
        return view('vote.index', compact('candidates'));
    }

    // Fungsi untuk memproses suara (vote)
    public function store(Request $request)
    {
        $user = Auth::user();

        // LOGIKA 1: Cek apakah user sudah pernah voting
        if ($user->has_voted) {
            return redirect()->back()->with('error', 'Maaf, Anda sudah memberikan suara!');
        }

        // Validasi tombol yang dikirim
        $request->validate([
            'candidate_id' => 'required|exists:candidates,id',
        ]);

        // LOGIKA 2: Simpan data voting ke tabel 'votes'
        Vote::create([
            'user_id' => $user->id,
            'candidate_id' => $request->candidate_id,
        ]);

        // LOGIKA 3: Ubah status siswa menjadi sudah voting (true)
        $user->update(['has_voted' => true]);

        return redirect()->back()->with('success', 'Terima kasih! Suara Anda berhasil disimpan.');
    }
    // Fungsi untuk menampilkan halaman Admin
    public function admin()
    {
        return view('vote.admin');
    }

    // Fungsi untuk memproses penambahan Paslon dari Admin
    public function storeCandidate(Request $request)
    {
        Candidate::create([
            'nomor_urut' => $request->nomor_urut,
            'nama_ketua' => $request->ketua,
            'nama_wakil' => $request->wakil,
            'foto' => $request->foto, // Menggunakan link URL foto
            'visi_misi' => $request->visi . " - " . $request->misi
        ]);

        return redirect()->back()->with('success', 'Paslon baru berhasil ditambahkan!');
    }
    // Fungsi untuk menampilkan halaman Hasil Live
    public function hasil()
    {
        // Mengambil semua data paslon beserta jumlah suaranya
        $candidates = Candidate::withCount('votes')->get();
        
        return view('vote.hasil', compact('candidates'));
    }
}
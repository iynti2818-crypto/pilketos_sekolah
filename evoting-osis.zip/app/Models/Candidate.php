<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Candidate extends Model
{
    use HasFactory;

    protected $fillable = ['nomor_urut', 'nama_ketua', 'nama_wakil', 'visi_misi', 'foto'];

    // Relasi: Satu kandidat bisa memiliki banyak suara (votes)
    public function votes()
    {
        return $this->hasMany(Vote::class);
    }
}